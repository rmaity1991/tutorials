<?php
    $response = array();
    $response['name'] = "Aditya";
    $response['message'] = "Welcome to Internshala Trainings";
    
    echo json_encode($response);
?>
